﻿using System;
using System.Collections.Generic;

#nullable disable

namespace ContractManager1.Models
{
    public partial class Domain
    {
        public string Alldomains { get; set; }
    }
}
